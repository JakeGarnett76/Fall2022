#ifndef WORLDGENERATION_H_
#define WORLDGENERATION_H_

void generateGrid();

#endif