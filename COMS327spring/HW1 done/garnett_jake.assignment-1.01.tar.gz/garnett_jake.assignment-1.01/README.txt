displayMap() shows the map in a 21x80 grid
emptyMap() fills the map with '.'
randomExits() adds four random exits to the side of the map
randomRoadNS() connects North and South exits
randomRoadWE() connects West and East exits
addEdge() adds a '%' edge to the map
generateTerrainSeeds() places the origin of the terrain
genTerr() grows the seeds
addBuildings() places the pokemart and pokecenter
distance() finds the distance bewtween two points

Program in HW1.c