Program that prints all paths a knight can take using Knights Tour.
I realized I was formatting my 2D array wrong. I wrote a function that corrects it, but I think it slows down my program a lot.
I implemented the show board method. I did it to see what was going wrong, then I saw it was on the pdf afterwards.
